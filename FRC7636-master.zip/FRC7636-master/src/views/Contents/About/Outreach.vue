<template>
    <div>
        <v-img
        aspect-ratio="2"
        src=""
        >
        </v-img>
        <div class="pa-10" style="background-color: #fafafa">
            <div style="background-color: #a2a2a2" class="mx-auto">
                Outreach
            </div>
        </div>
    </div>
</template>

<script>
export default {
    
}
</script>